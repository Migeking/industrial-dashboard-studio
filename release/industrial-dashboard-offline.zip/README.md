# Industrial Dashboard Studio

工业大屏产品化工作区，目标是把现有的三套工业监控样板沉淀为可复用运行时、场景配置、HMI/SCADA 基础能力和可交付 Skill。本目录是独立文件夹，不创建 Git 仓库。

## 当前基线

- `apps/showcase/index.html`：横屏互动体验入口，支持全屏体验与三场景切换。
- `apps/scada-designer/index.html`：可编辑标题、主题色、设备和状态的 SCADA 场景设计器，可导出 JSON 配置。
- `scenarios/`：按水务、设备维护、反应安全分组的三套离线样板。
- `packages/`：可运行的运行时、组件、数据适配器和设计系统。
- `skills/industrial-dashboard/`：离线交付的大屏生成与验收 Skill。
- `tests/interaction_check.py`：三套样板的交互验收。

## 本地打开

直接打开 `apps/showcase/index.html` 即可进入体验入口。手机端请横屏；竖屏会显示旋转提示。

## 验证

```bash
node skills/industrial-dashboard/scripts/validate-dashboard.js scenarios
python -X utf8 tests/interaction_check.py
```

## 产品化路线

当前已完成离线样板、运行时与适配器骨架、横屏互动入口和 SCADA 配置编辑器。下一阶段接入经确认的 REST/WebSocket 数据契约，再进入现场部署。
